#!/usr/bin/env python3
"""
Part 5 - analytical (geometric) Jacobian for the ABB IRB1600ID, derived from
the same modified-DH model as DH_mat.m. Pure numpy, no ROS/MoveIt required,
so it can be run on its own to get the "by hand" Jacobian and cross-checked
independently before ever touching RobotState::getJacobian().

-----------------------------------------------------------------------------
WHY THIS FILE EXISTS, NOT JUST DH_mat.m
-----------------------------------------------------------------------------
DH_mat.m hard-codes theta_i for ONE configuration at a time (whatever pose you
last solved IK for) and only builds T(:,:,i). It does not build the Jacobian,
and it does not track how theta_i (the DH variable used inside T_DH) relates
to q_i (the actual joint_i value MoveIt/KDL/the URDF reports). That relation
is NOT theta_i = q_i for every joint - and this matters a lot for Part 5.

-----------------------------------------------------------------------------
THE THETA vs Q SUBTLETY (READ THIS BEFORE TRUSTING A JACOBIAN COMPARISON)
-----------------------------------------------------------------------------
Comparing DH_mat.m's PLACE-pose thetas against the PLACE group_state in the
SRDF shows:

    theta_1 =  q1                  (no change)
    theta_2 =  pi/2 - q2           <- DH_mat.m comment: "Subtracted to pitch forward"
    theta_3 = -q3                  <- DH_mat.m comment: "Negated to pitch down"
    theta_4 =  q4
    theta_5 =  pi + q5
    theta_6 =  q6

MoveIt / KDL / get_jacobian() report the Jacobian with respect to q_i (the
real joint variable, what qdot means in a JointTrajectory). If you build the
classic geometric Jacobian column

    J_i = [ z_i x (p_e - p_i) ;  z_i ]

using z_i and p_i taken straight from the DH chain (i.e. differentiating with
respect to theta_i), columns 2 and 3 will come out with the WRONG SIGN
relative to MoveIt's Jacobian, because dtheta_2/dq_2 = -1 and dtheta_3/dq_3 =
-1. Column i must be scaled by dtheta_i/dq_i (chain rule):

    J_i(q) = (dtheta_i/dq_i) * [ z_i x (p_e - p_i) ; z_i ]

SIGN below is exactly that vector, read off the offsets above. If your hand
derivation in the report skips this, your analytical Jacobian will disagree
with MoveIt on joints 2 and 3 even though both are "correct" - they are just
correct with respect to different variables. Say this explicitly when you
defend it live.

-----------------------------------------------------------------------------
THE d4 / d6 SPLIT (was wrong, now fixed - keep this explanation for the viva)
-----------------------------------------------------------------------------
An earlier version of this table had

    d4 = 0.678,  d6 = 0.135,  plus a 0.027 m translation inside T_OFFSET

which sums to 0.840 m. The URDF gives the same total a different way:

    joint_3 -> wrist centre  = 0.151 + 0.489 = 0.640 m
    wrist centre -> tool0    =                 0.200 m
                                               -----
                                               0.840 m

Same total, wrong split. The consequence is subtle and worth understanding,
because it is exactly the kind of thing that survives a careless check:

  - at HOME the wrist is straight, the two errors cancel, and the FK position
    is correct to the millimetre - so a spot-check at HOME finds nothing
  - as joints 4-6 rotate the errors stop cancelling: 13.6 mm of position
    error at PICK, 33.1 mm at PLACE
  - the Jacobian's LINEAR rows were off by up to 0.038 = 0.678 - 0.640
    everywhere, including at HOME where the position looked perfect
  - the ANGULAR rows were correct throughout, because joint axis directions
    do not depend on how the link lengths are apportioned

With d4 = 0.640 and d6 = 0.200 (and no extra translation in T_OFFSET), this
module reproduces the URDF chain - and therefore KDL - to machine precision at
HOME, PICK and PLACE.

Moral for the report: matching FK at a single configuration does not validate
a DH table. Check at a configuration where the wrist is bent.
-----------------------------------------------------------------------------
"""

import numpy as np

# --- DH table (modified/Craig convention, matching T_DH in DH_mat.m) -------
#   columns: a_i, alpha_i, d_i (called s_i in DH_mat.m)
A     = [0.0,    0.150,     0.700, 0.110,     0.0,      0.0]
ALPHA = [0.0,    np.pi / 2, 0.0,   np.pi / 2, np.pi / 2, np.pi / 2]
D     = [0.4865, 0.0,       0.0,   0.640,     0.0,       0.200]

# theta_i = SIGN_i * q_i + OFFSET_i   (read off DH_mat.m's comments)
SIGN   = [ 1.0, -1.0, -1.0, 1.0, 1.0, 1.0]
OFFSET = [ 0.0, np.pi / 2, 0.0, 0.0, np.pi, 0.0]

# Fixed flange -> tool0 correction used in DH_mat.m (does not depend on q)
T_OFFSET = np.array([
    [0, 0, -1, 0.000],
    [0, 1,  0, 0.000],
    [1, 0,  0, 0.000],
    [0, 0,  0, 1.000],
])

JOINT_NAMES = [f"joint_{i}" for i in range(1, 7)]

# From the SRDF group_states (config/abb_irb1600id.srdf) - handy for quick checks
CONFIGS = {
    "HOME":  [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
    "PICK":  [-1.1629, 0.7666, 0.4924, 0.0, 0.3602, 0.0],
    "PLACE": [0.8852, 1.3914, -0.6997, 0.0, 0.9026, 0.0],
}


def T_DH(a, alpha, d, theta):
    """Exactly the matrix built by T_DH() in DH_mat.m."""
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([
        [ct,        -st,       0.0,   a],
        [ca * st,  ca * ct,   -sa,   -d * sa],
        [sa * st,  sa * ct,    ca,    d * ca],
        [0.0,       0.0,       0.0,   1.0],
    ])


def fk_frames(q):
    """
    Forward kinematics of the 6-DOF chain.

    Returns (frames, T_e):
      frames[i] = 0_T_(i+1), the base->frame transform after joint i+1 has
                  been applied (0-indexed list, length 6)
      T_e       = base -> tool0 transform (frames[5] with T_OFFSET applied)
    """
    q = np.asarray(q, dtype=float)
    T = np.eye(4)
    frames = []
    for i in range(6):
        theta_i = SIGN[i] * q[i] + OFFSET[i]
        T = T @ T_DH(A[i], ALPHA[i], D[i], theta_i)
        frames.append(T.copy())
    T_e = frames[-1] @ T_OFFSET
    return frames, T_e


def fk(q):
    """Convenience: base->tool0 transform only."""
    _, T_e = fk_frames(q)
    return T_e


def analytical_jacobian(q):
    """
    Geometric Jacobian, 6xN, columns ordered [dx;dy;dz;wx;wy;wz] wrt joint
    velocities qdot (all-revolute chain), with the theta-vs-q sign correction
    applied. This is the "by hand" formula:

        J_v_i = (dtheta_i/dq_i) * z_i x (p_e - p_i)
        J_w_i = (dtheta_i/dq_i) * z_i

    z_i, p_i are the z-axis and origin of frame i (frames[i] below), which in
    this modified-DH chain both lie exactly on joint i's rotation axis (the
    Rz(theta_i) step never moves its own axis, and the following Trans_z(d_i)
    step moves along that same axis) - so no separate "axis point" bookkeeping
    is needed beyond frames[i] itself.
    """
    frames, T_e = fk_frames(q)
    p_e = T_e[:3, 3]
    J = np.zeros((6, 6))
    for i in range(6):
        z_i = frames[i][:3, 2]
        p_i = frames[i][:3, 3]
        J[:3, i] = SIGN[i] * np.cross(z_i, p_e - p_i)
        J[3:, i] = SIGN[i] * z_i
    return J


def numeric_jacobian(q, eps=1e-6):
    """
    Finite-difference cross-check of analytical_jacobian(), useful as a
    sanity test independent of the hand-derived formula above (linear part
    from central differences of position; angular part from the skew-
    symmetric part of the relative rotation between q+eps and q-eps).
    """
    J = np.zeros((6, 6))
    for i in range(6):
        qp = np.array(q, dtype=float); qp[i] += eps
        qm = np.array(q, dtype=float); qm[i] -= eps
        Tp, Tm = fk(qp), fk(qm)
        J[:3, i] = (Tp[:3, 3] - Tm[:3, 3]) / (2 * eps)
        dR = Tp[:3, :3] @ Tm[:3, :3].T
        J[3:, i] = np.array([dR[2, 1] - dR[1, 2],
                              dR[0, 2] - dR[2, 0],
                              dR[1, 0] - dR[0, 1]]) / (4 * eps)
    return J


def manipulability(J):
    return float(np.linalg.det(J @ J.T))


def _report(name, q):
    J = analytical_jacobian(q)
    Jn = numeric_jacobian(q)
    T_e = fk(q)
    np.set_printoptions(precision=4, suppress=True)
    print(f"\n{'=' * 70}\n{name}   q = {np.round(q, 4).tolist()}\n{'=' * 70}")
    print(f"tool0 position : {T_e[:3, 3]}")
    print(f"Analytical Jacobian (base frame, order [vx vy vz wx wy wz]):\n{J}")
    print(f"max |analytical - finite-difference| = {np.max(np.abs(J - Jn)):.3e}"
          "   (should be ~1e-9 or smaller; this only checks internal "
          "consistency of the formula, not agreement with the real robot)")
    print(f"Manipulability det(J J^T) = {manipulability(J):.6e}")


if __name__ == "__main__":
    for name, q in CONFIGS.items():
        _report(name, q)
