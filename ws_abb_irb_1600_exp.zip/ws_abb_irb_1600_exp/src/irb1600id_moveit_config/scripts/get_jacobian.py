#!/usr/bin/env python3
"""
Part 5 - RobotState::getJacobian() (KDL, via MoveItPy) vs the hand-derived
analytical Jacobian in analytical_jacobian.py, at a chosen configuration.

The original version of this script always read "whatever /joint_states
currently says", which only lets you check one pose per run and ties the
check to whatever RViz happens to be showing. This version sets an explicit
RobotState instead, so you can ask for HOME, PICK, PLACE, or any of the 4B/4D
waypoints on demand - which is what the statement actually asks for (compare
the Jacobian at the fine-approach segments, not just at rest).

Usage (with move_group already running, e.g. via demo.launch.py):

    ros2 run irb1600id_moveit_config get_jacobian.py --config PICK
    ros2 run irb1600id_moveit_config get_jacobian.py --config PLACE
    ros2 run irb1600id_moveit_config get_jacobian.py --config HOME
    ros2 run irb1600id_moveit_config get_jacobian.py --joints "-0.3,0.9,0.2,0.0,0.4,0.0"

Prints, side by side: the KDL Jacobian from MoveIt, the analytical Jacobian,
their element-wise difference, and both manipulability indices.
"""

import argparse
import time

import numpy as np
import rclpy
from moveit.planning import MoveItPy
from moveit_configs_utils import MoveItConfigsBuilder

import analytical_jacobian as aj

GROUP = "manipulator"
TIP = "tool0"


def parse_args():
    p = argparse.ArgumentParser()
    group = p.add_mutually_exclusive_group(required=True)
    group.add_argument("--config", choices=sorted(aj.CONFIGS.keys()),
                        help="Named configuration from the SRDF group_states.")
    group.add_argument("--joints", type=str,
                        help="Comma-separated q1,...,q6 in radians.")
    return p.parse_args()


def main():
    args = parse_args()
    if args.config:
        q = aj.CONFIGS[args.config]
        label = args.config
    else:
        q = [float(v) for v in args.joints.split(",")]
        if len(q) != 6:
            raise SystemExit(f"--joints needs 6 values, got {len(q)}")
        label = "custom"

    rclpy.init()

    moveit_config_dict = (
        # The first argument must match config/abb_irb1600id.srdf. "irb1600id"
        # makes the builder look for config/irb1600id.srdf, find nothing, and
        # bring MoveItPy up with no planning group.
        MoveItConfigsBuilder("abb_irb1600id", package_name="irb1600id_moveit_config")
        .planning_pipelines(pipelines=["ompl"])
        .to_moveit_configs()
        .to_dict()
    )
    moveit_config_dict.update({
        "planning_pipelines": {"pipeline_names": ["ompl"]},
        "plan_request_params": {
            "planning_attempts": 1,
            "planning_pipeline": "ompl",
            "max_velocity_scaling_factor": 1.0,
            "max_acceleration_scaling_factor": 1.0,
        },
    })

    abb_irb = MoveItPy(node_name="jacobian_calculator", config_dict=moveit_config_dict)
    time.sleep(1.0)  # let the planning scene monitor come up

    robot_model = abb_irb.get_robot_model()

    # Build an explicit RobotState at q, instead of trusting "current state".
    from moveit.core.robot_state import RobotState
    robot_state = RobotState(robot_model)
    robot_state.set_joint_group_positions(GROUP, list(q))
    robot_state.update()

    # The Python binding takes the group NAME as a string and a numpy
    # reference point - not JointModelGroup / LinkModel objects, which is what
    # the C++ signature takes. Passing the objects raises a TypeError.
    # The result is in the model frame (base_link here), the same frame as
    # get_global_link_transform(), so it is directly comparable with the
    # analytical Jacobian below with no change of basis.
    reference_point = np.array([0.0, 0.0, 0.0], dtype=float)
    jacobian_kdl = np.asarray(
        robot_state.get_jacobian(GROUP, reference_point)
    ).reshape(6, 6)

    jacobian_hand = aj.analytical_jacobian(q)
    diff = jacobian_kdl - jacobian_hand

    np.set_printoptions(precision=4, suppress=True)
    print(f"\n=== Configuration: {label}   q = {np.round(q, 4).tolist()} ===")
    print(f"\n--- KDL Jacobian (RobotState::getJacobian) ---\n{jacobian_kdl}")
    print(f"\n--- Analytical Jacobian (DH, hand-derived) ---\n{jacobian_hand}")
    print(f"\n--- Difference (KDL - analytical) ---\n{diff}")
    print(f"\nmax |difference| = {np.max(np.abs(diff)):.4f}")
    print(f"KDL manipulability        det(J J^T) = "
          f"{aj.manipulability(jacobian_kdl):.6e}")
    print(f"Analytical manipulability det(J J^T) = "
          f"{aj.manipulability(jacobian_hand):.6e}")

    if np.max(np.abs(diff)) > 1e-6:
        print(
            "\nNOTE: with the corrected d4 = 0.640 / d6 = 0.200 split these "
            "should agree to ~1e-12. A gap reappearing here means a DH link "
            "parameter has drifted again - check at a BENT-wrist "
            "configuration, not at HOME, where errors can cancel."
        )
    else:
        print("\nAgreement to machine precision.")

    rclpy.shutdown()


if __name__ == "__main__":
    main()
