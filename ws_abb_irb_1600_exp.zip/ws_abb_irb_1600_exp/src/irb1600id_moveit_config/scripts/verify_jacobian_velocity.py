#!/usr/bin/env python3
"""
Part 5 - closing the loop: does J(q) @ qdot actually reproduce the tool speed
the chosen profile (quintic, per part4_results.json) demanded, on the 4B and
4D fine-approach segments?

This does NOT need ROS or MoveIt running - it only needs the CSV files that
master_cycle.py's fine_approach() now writes (part5_4B_waypoints.csv and
part5_4D_waypoints.csv, one row per retimed waypoint: t, q1..q6, qd1..qd6, s,
sdot_target). It reads those, evaluates the analytical Jacobian at each q,
and compares |J_v(q) @ qdot| against sdot_target.

Why this is a real check and not circular:
  - qdot in the CSV comes from finite-differencing q(t) along the retimed
    path (cartesian.py, retime()).
  - sdot_target comes from evaluating the cubic/quintic law directly
    (profiles.py) at the same instants.
  - J(q) comes from the DH model (analytical_jacobian.py), built and
    validated completely independently of both of the above.
  Agreement of all three means: the IK solutions along the line, the
  imposed timing, and the kinematic model all tell the same story about
  how fast the tool is actually moving.

Usage, from the scripts/ directory, after running master_cycle.py once:

    python3 verify_jacobian_velocity.py part5_4B_waypoints.csv
    python3 verify_jacobian_velocity.py part5_4D_waypoints.csv

Optionally saves a plot (t vs speed, both curves) if matplotlib is present.
"""

import csv
import sys

import numpy as np

import analytical_jacobian as aj

def load_csv(path):
    rows = []
    with open(path, newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append({k: float(v) for k, v in row.items()})
    return rows


def main():
    if len(sys.argv) != 2:
        raise SystemExit(f"usage: {sys.argv[0]} <waypoints.csv>")
    path = sys.argv[1]
    rows = load_csv(path)

    t, predicted, target, err = [], [], [], []
    for row in rows:
        q = [row[f"q{i}"] for i in range(1, 7)]
        qdot = [row[f"qd{i}"] for i in range(1, 7)]
        J = aj.analytical_jacobian(q)
        v_pred = J[:3, :] @ np.array(qdot)
        speed_pred = float(np.linalg.norm(v_pred))
        speed_target = row["sdot_target"]

        t.append(row["t"])
        predicted.append(speed_pred)
        target.append(speed_target)
        err.append(speed_pred - speed_target)

    t = np.array(t); predicted = np.array(predicted)
    target = np.array(target); err = np.array(err)

    print(f"\n=== {path} ===")
    print(f"{'t [s]':>8} {'|J*qdot| [m/s]':>16} {'profile s_dot [m/s]':>20} "
          f"{'diff [m/s]':>12}")
    for i in range(len(t)):
        print(f"{t[i]:8.4f} {predicted[i]:16.4f} {target[i]:20.4f} {err[i]:12.4f}")

    print(f"\npeak |J*qdot|        = {np.max(predicted):.4f} m/s")
    print(f"peak profile s_dot   = {np.max(target):.4f} m/s")
    print(f"max |difference|     = {np.max(np.abs(err)):.4f} m/s")
    print(f"RMS difference       = {np.sqrt(np.mean(err**2)):.4f} m/s")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.plot(t, target, "k--", label="profile s_dot(t) (target)")
        ax.plot(t, predicted, "tab:blue", marker="o", ms=3,
                label="|J(q) @ qdot| (Jacobian prediction)")
        ax.set_xlabel("time [s]")
        ax.set_ylabel("tool speed [m/s]")
        ax.set_title(f"Part 5 velocity check - {path}")
        ax.legend()
        ax.grid(alpha=0.3)
        out_png = path.replace(".csv", "_jacobian_check.png")
        fig.tight_layout()
        fig.savefig(out_png, dpi=150)
        print(f"\nwrote {out_png}")
    except ImportError:
        print("\n[verify_jacobian_velocity] matplotlib not installed, skipping plot.")


if __name__ == "__main__":
    main()
