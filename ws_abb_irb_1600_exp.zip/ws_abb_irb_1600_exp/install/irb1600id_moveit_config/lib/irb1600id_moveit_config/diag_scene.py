#!/usr/bin/env python3
"""
Diagnostic only - does not move the robot.

Answers three questions in order:
  1. Are the moveit_py.yaml parameters reaching the node at all?
  2. After apply_collision_object(), what does MoveItPy's own scene contain?
  3. Does a configuration known to intersect the pole report as colliding?

Run with:  ros2 launch irb1600id_moveit_config diag.launch.py
(with demo.launch.py already running in another terminal)
"""

import os
import sys

import numpy as np
import rclpy

from moveit.planning import MoveItPy
from moveit.core.robot_state import RobotState

import scene as scene_mod

GROUP = "manipulator"


LOG = None


def say(text):
    """
    Every line goes through the ROS logger, not print().

    say() is buffered when launch captures stdout, and moveit_py segfaults
    while destroying MoveItCpp at exit, so the buffer is lost and the script
    looks like it produced nothing at all. The logger writes straight out.
    """
    for line in str(text).splitlines() or [""]:
        LOG.info(line)


def show(title):
    say("")
    say("=" * 70)
    say(title)
    say("=" * 70)


def world_object_ids(scene):
    """Try the bound accessors in order; report which one worked."""
    for attr in ("get_planning_scene_msg", "planning_scene_message"):
        if hasattr(scene, attr):
            member = getattr(scene, attr)
            msg = member() if callable(member) else member
            ids = [o.id for o in msg.world.collision_objects]
            attached = [a.object.id
                        for a in msg.robot_state.attached_collision_objects]
            return attr, ids, attached
    return None, None, None


def main():
    global LOG
    rclpy.init()
    moveit = MoveItPy(node_name="scene_diag")
    robot_model = moveit.get_robot_model()
    psm = moveit.get_planning_scene_monitor()
    helper = rclpy.create_node("scene_diag_helper")
    LOG = helper.get_logger()

    try:
        _run(moveit, robot_model, psm, helper)
    except Exception:  # noqa: BLE001
        import traceback
        for line in traceback.format_exc().splitlines():
            LOG.error(line)

    say("diagnostic finished")
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)


def _run(moveit, robot_model, psm, helper):
    # --- 1. are our parameters present? ---------------------------------
    show("1. parameters")
    for name in ("planning_scene_monitor_options.publish_planning_scene_topic",
                 "planning_scene_monitor_options.monitored_planning_scene_topic",
                 "ompl_rrtstar.plan_request_params.planner_id"):
        try:
            value = helper.get_parameter_or(name, None)
            say(f"  {name} = {value.value if value else 'NOT SET on helper node'}")
        except Exception as exc:  # noqa: BLE001
            say(f"  {name} -> {exc}")
    say("  (these live on the moveit_py node, not the helper; if the log line")
    say("   at startup said 'monitored_planning_scene' then the yaml is not")
    say("   being applied and that is finding #1)")

    # --- 2. what is in the local scene? ---------------------------------
    show("2. MoveItPy's own planning scene")
    objects = scene_mod.build_objects()
    say(f"  applying {len(objects)} objects: {[o.id for o in objects]}")
    say(f"  frame_id used: {objects[0].header.frame_id}")

    with psm.read_write() as scene:
        for obj in objects:
            scene.apply_collision_object(obj)
        scene.current_state.update()

    with psm.read_only() as scene:
        accessor, ids, attached = world_object_ids(scene)
        if accessor is None:
            say("  could not find get_planning_scene_msg or "
                  "planning_scene_message on this build")
        else:
            say(f"  read back via {accessor}()")
            say(f"  world objects : {ids}")
            say(f"  attached      : {attached}")
        try:
            say(f"  planning frame: {scene.planning_frame}")
        except AttributeError:
            pass

    # --- 3. collision check at a configuration inside the pole ----------
    show("3. collision check")
    home = np.zeros(6)
    pick = np.array([-1.1629, 0.7666, 0.4924, 0.0, 0.3602, 0.0])

    state = RobotState(robot_model)
    for alpha in (0.0, 0.3, 0.5, 0.58, 0.7, 1.0):
        q = home + alpha * (pick - home)
        state.set_joint_group_positions(GROUP, list(q))
        state.update()
        with psm.read_only() as scene:
            colliding = scene.is_state_colliding(
                robot_state=state, joint_model_group_name=GROUP, verbose=False
            )
        tool = np.asarray(state.get_global_link_transform("tool0"))[:3, 3]
        flag = "COLLIDING" if colliding else "free"
        say(f"  alpha={alpha:4.2f}  tool=({tool[0]:6.3f},{tool[1]:7.3f},"
              f"{tool[2]:6.3f})  {flag}")

    say("\n  Expected: alpha 0.5-0.7 COLLIDING (that is where the forearm")
    say("  sweeps through the pole), alpha 0.0 and 1.0 free.")
    say("  All free  -> the pole is not in this scene.")
    say("  All COLLIDING -> the ACM is missing its SRDF entries instead.\n")


if __name__ == "__main__":
    main()
