#!/usr/bin/env python3
"""
Part 4 - collision scene for the IRB 1600ID assembly cell.

Why this replaces the old pick_and_place.py:

  The previous version created a publisher on /collision_object and published
  three messages roughly two seconds later, then destroyed the node. That is a
  race: a freshly created publisher usually has no matched subscriber yet, so
  the messages go nowhere and the scene silently stays empty. Because
  /collision_object is fire-and-forget there is no way to tell that it failed.

  Here we call the /apply_planning_scene service instead. It is synchronous,
  move_group answers with success/failure, and the objects end up in the scene
  that move_group actually plans against - which is also the scene RViz draws.

Object layout (all in base_link, metres). Positions are derived from the FK of
the SRDF states, so the numbers here are not free parameters:

    PICK  tool0 = (0.3677, -0.8509, 0.2155)
    PLACE tool0 = (0.8846,  1.0814, 0.0880)

  pick_table   support under the part, top face at the part's underside
  piece        50 mm cube, top face exactly at the PICK height
  obstacle     vertical pole between HOME and pre-pick - this is the thing
               4A has to go around. Verified offline: a straight joint-space
               interpolation from HOME to PICK drives the forearm 79 mm into
               this pole, so OMPL is genuinely forced to detour.
  place_table  deposit surface, top face at the part's underside at PLACE
"""

import sys

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Pose
from moveit_msgs.msg import (
    AttachedCollisionObject,
    CollisionObject,
    PlanningScene,
)
from moveit_msgs.srv import ApplyPlanningScene
from shape_msgs.msg import SolidPrimitive

FRAME = "base_link"
EEF_LINK = "link_6"          # tool0 is a massless frame; link_6 carries the geometry
TOUCH_LINKS = ["link_6", "link_5"]

PICK_XY = (0.3677, -0.8509)
PICK_Z = 0.2155
PLACE_XY = (0.8846, 1.0814)
PLACE_Z = 0.0880

PIECE_SIZE = 0.05

# Gap between a table's top face and the underside of the part resting on it.
# Without it the two surfaces are exactly coincident, MoveIt reports a
# persistent "pick_table - piece" contact, and the moment the part is attached
# to the flange that contact invalidates the start state of the next plan -
# touch_links can whitelist robot links but not other world objects.
SURFACE_CLEARANCE = 0.005


def _box(object_id, size, position):
    obj = CollisionObject()
    obj.header.frame_id = FRAME
    obj.id = object_id
    prim = SolidPrimitive()
    prim.type = SolidPrimitive.BOX
    prim.dimensions = [float(v) for v in size]
    pose = Pose()
    pose.position.x, pose.position.y, pose.position.z = [float(v) for v in position]
    pose.orientation.w = 1.0
    obj.primitives.append(prim)
    obj.primitive_poses.append(pose)
    obj.operation = CollisionObject.ADD
    return obj


def _cylinder(object_id, height, radius, position):
    obj = CollisionObject()
    obj.header.frame_id = FRAME
    obj.id = object_id
    prim = SolidPrimitive()
    prim.type = SolidPrimitive.CYLINDER
    # SolidPrimitive.CYLINDER dimensions are [height, radius], in that order.
    prim.dimensions = [float(height), float(radius)]
    pose = Pose()
    pose.position.x, pose.position.y, pose.position.z = [float(v) for v in position]
    pose.orientation.w = 1.0
    obj.primitives.append(prim)
    obj.primitive_poses.append(pose)
    obj.operation = CollisionObject.ADD
    return obj


def build_objects():
    """The four scene objects the statement asks for."""
    piece_centre_z = PICK_Z - PIECE_SIZE / 2.0        # 0.1905
    piece_bottom = piece_centre_z - PIECE_SIZE / 2.0  # 0.1655

    pick_top = piece_bottom - SURFACE_CLEARANCE
    pick_table = _box(
        "pick_table",
        size=(0.35, 0.35, pick_top),
        position=(PICK_XY[0], PICK_XY[1], pick_top / 2.0),
    )

    piece = _box(
        "piece",
        size=(PIECE_SIZE, PIECE_SIZE, PIECE_SIZE),
        position=(PICK_XY[0], PICK_XY[1], piece_centre_z),
    )

    obstacle = _cylinder(
        "obstacle",
        height=1.40,
        radius=0.08,
        position=(0.60, -0.48, 0.70),
    )

    place_bottom = PLACE_Z - PIECE_SIZE / 2.0         # 0.063
    place_top = place_bottom - SURFACE_CLEARANCE
    place_table = _box(
        "place_table",
        size=(0.40, 0.40, place_top),
        position=(PLACE_XY[0], PLACE_XY[1], place_top / 2.0),
    )

    return [pick_table, piece, obstacle, place_table]


class SceneClient:
    """Thin synchronous wrapper around /apply_planning_scene."""

    def __init__(self, node: Node, timeout=10.0):
        self._node = node
        self._client = node.create_client(ApplyPlanningScene, "/apply_planning_scene")
        if not self._client.wait_for_service(timeout_sec=timeout):
            raise RuntimeError(
                "/apply_planning_scene not available - is move_group running? "
                "Start demo.launch.py first."
            )

    def _send(self, scene: PlanningScene):
        scene.is_diff = True
        request = ApplyPlanningScene.Request()
        request.scene = scene
        future = self._client.call_async(request)
        rclpy.spin_until_future_complete(self._node, future, timeout_sec=10.0)
        result = future.result()
        if result is None or not result.success:
            raise RuntimeError("apply_planning_scene rejected the diff")
        return result

    def add_objects(self, objects):
        scene = PlanningScene()
        scene.world.collision_objects.extend(objects)
        return self._send(scene)

    # NOTE: there is deliberately no allow_collision() helper here any more.
    # An AllowedCollisionMatrix inside a PlanningScene diff does NOT merge with
    # the existing one - PlanningScene::setPlanningSceneDiffMsg calls
    # setAllowedCollisionMatrixMsg, which REPLACES the matrix wholesale. Sending
    # a small ACM to permit one contact therefore deletes every
    # <disable_collisions> pair the Setup Assistant generated, so every adjacent
    # link pair starts colliding and nothing can be planned afterwards.
    #
    # The supported way to permit the grasp contact is touch_links on the
    # AttachedCollisionObject below, plus a small stand-off so the flange never
    # has to be in contact before the attach happens.

    def attach(self, object_id, link=EEF_LINK, touch_links=None):
        """
        Move an object from the world into the robot's hand.

        Note there is no explicit world REMOVE here. When an
        AttachedCollisionObject with ADD carries no shapes, MoveIt looks the id
        up in the world and moves it across itself, deleting the world copy as
        part of the same operation. Adding our own REMOVE afterwards then acts
        on an id that no longer exists, processCollisionObjectMsg returns false,
        and the whole ApplyPlanningScene call reports failure even though the
        attach itself worked.
        """
        scene = PlanningScene()

        aco = AttachedCollisionObject()
        aco.link_name = link
        aco.object.id = object_id
        aco.object.header.frame_id = FRAME
        aco.object.operation = CollisionObject.ADD
        aco.touch_links = list(touch_links or TOUCH_LINKS)
        scene.robot_state.attached_collision_objects.append(aco)
        scene.robot_state.is_diff = True

        return self._send(scene)

    def detach(self, object_id, link=EEF_LINK):
        """Put the object back into the world at wherever the hand left it."""
        scene = PlanningScene()
        aco = AttachedCollisionObject()
        aco.link_name = link
        aco.object.id = object_id
        aco.object.operation = CollisionObject.REMOVE
        scene.robot_state.attached_collision_objects.append(aco)
        scene.robot_state.is_diff = True
        return self._send(scene)


# --------------------------------------------------------------------------
# MoveItPy's own planning scene
#
# MoveItPy runs a PlanningSceneMonitor that is completely separate from
# move_group's. Pushing objects to move_group via /apply_planning_scene makes
# them appear in RViz and makes /compute_cartesian_path respect them, but it
# does NOT populate the scene MoveItPy plans against - so OMPL happily routes
# straight through the obstacle.
#
# Rather than rely on topic mirroring, we write the same objects into both
# scenes explicitly. Two scenes, both populated, no ordering assumptions.
# --------------------------------------------------------------------------

def apply_to_local_scene(psm, objects):
    """Write collision objects into MoveItPy's own planning scene."""
    with psm.read_write() as scene:
        for obj in objects:
            scene.apply_collision_object(obj)
        scene.current_state.update()


def attach_local(psm, object_id, link=EEF_LINK, touch_links=None):
    aco = AttachedCollisionObject()
    aco.link_name = link
    aco.object.id = object_id
    aco.object.header.frame_id = FRAME
    aco.object.operation = CollisionObject.ADD
    aco.touch_links = list(touch_links or TOUCH_LINKS)
    with psm.read_write() as scene:
        scene.process_attached_collision_object(aco)
        scene.current_state.update()


def detach_local(psm, object_id, link=EEF_LINK):
    aco = AttachedCollisionObject()
    aco.link_name = link
    aco.object.id = object_id
    aco.object.operation = CollisionObject.REMOVE
    with psm.read_write() as scene:
        scene.process_attached_collision_object(aco)
        scene.current_state.update()


def verify_obstacle_seen(psm, robot_state, group="manipulator", logger=None):
    """
    Self-test: sweep a straight joint-space interpolation from HOME to PICK and
    confirm that (a) some configuration along it collides, and (b) the two
    endpoints do not.

    The sweep matters. An earlier version of this test probed a single alpha
    chosen from an offline estimate that modelled the links as line segments
    between joint origins. The real collision meshes give a narrower window -
    alpha 0.50 collides, 0.58 does not - so the single probe returned "free"
    and wrongly declared the obstacle missing.

    (a) failing means the pole is not in this scene: 4A will plan through it.
    (b) failing means the ACM has lost its SRDF <disable_collisions> entries,
        so the robot self-collides everywhere and nothing will plan.
    """
    import numpy as np

    home = np.zeros(6)
    pick = np.array([-1.1629, 0.7666, 0.4924, 0.0, 0.3602, 0.0])

    def colliding(alpha):
        robot_state.set_joint_group_positions(
            group, list(home + alpha * (pick - home))
        )
        robot_state.update()
        with psm.read_only() as scene:
            return bool(scene.is_state_colliding(
                robot_state=robot_state, joint_model_group_name=group,
                verbose=False,
            ))

    endpoints_free = not colliding(0.0) and not colliding(1.0)

    hits = [round(float(a), 3)
            for a in np.linspace(0.30, 0.80, 26) if colliding(a)]

    if logger is not None:
        if hits:
            logger.info(f"  obstacle intersects the direct path over "
                        f"alpha {min(hits):.2f}-{max(hits):.2f} "
                        f"({len(hits)} of 26 samples)")
        logger.info(f"  HOME and PICK collision-free: {endpoints_free}")

    return bool(hits) and endpoints_free


def main():
    rclpy.init()
    node = rclpy.create_node("scene_spawner")
    try:
        client = SceneClient(node)
        client.add_objects(build_objects())
        node.get_logger().info(
            "Scene applied: pick_table, piece, obstacle, place_table. "
            "They should be visible in RViz now."
        )
    except RuntimeError as exc:
        node.get_logger().error(str(exc))
        return 1
    finally:
        node.destroy_node()
        rclpy.shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
