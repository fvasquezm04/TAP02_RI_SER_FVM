#!/usr/bin/env python3
"""
Direct trajectory execution for the retimed 4B / 4D segments.

Why not MoveItCpp.execute()?

  execute() calls ensureActiveControllersForGroup(trajectory.getGroupName()),
  and a RobotTrajectory rebuilt from a message through the Python bindings
  comes back with an empty group name. The result is
  "No active controllers configured for group ''" and nothing moves.

  Sending the trajectory to the controller's FollowJointTrajectory action
  sidesteps that entirely, and has a second benefit that matters for Part 4B:
  the timing we computed is what the controller receives, with nothing in
  between that could re-parameterise it. When we claim the tool followed a
  quintic profile, this is what makes that claim true.
"""

import rclpy
from rclpy.action import ActionClient
from control_msgs.action import FollowJointTrajectory


class TrajectoryRunner:
    def __init__(self, node,
                 action_name="/manipulator_controller/follow_joint_trajectory",
                 timeout=10.0):
        self._node = node
        self._client = ActionClient(node, FollowJointTrajectory, action_name)
        if not self._client.wait_for_server(timeout_sec=timeout):
            raise RuntimeError(
                f"{action_name} not available - is the controller spawned? "
                "Check `ros2 control list_controllers`."
            )

    def run(self, joint_trajectory, timeout=120.0):
        """
        joint_trajectory: trajectory_msgs/JointTrajectory, already timed.
        Blocks until the controller reports completion. Returns True on success.
        """
        goal = FollowJointTrajectory.Goal()
        goal.trajectory = joint_trajectory
        # Stamp 0 means "start now" rather than at an absolute past time, which
        # the controller would reject outright.
        goal.trajectory.header.stamp.sec = 0
        goal.trajectory.header.stamp.nanosec = 0

        send = self._client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self._node, send, timeout_sec=10.0)
        handle = send.result()
        if handle is None or not handle.accepted:
            self._node.get_logger().error("  controller rejected the trajectory")
            return False

        result_future = handle.get_result_async()
        rclpy.spin_until_future_complete(self._node, result_future,
                                         timeout_sec=timeout)
        result = result_future.result()
        if result is None:
            self._node.get_logger().error("  trajectory execution timed out")
            return False

        code = result.result.error_code
        if code != FollowJointTrajectory.Result.SUCCESSFUL:
            self._node.get_logger().error(
                f"  controller returned error_code {code}: "
                f"{result.result.error_string}"
            )
            return False
        return True
