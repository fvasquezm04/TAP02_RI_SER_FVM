from launch import LaunchDescription
from launch.actions import SetEnvironmentVariable
from launch_ros.actions import Node
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    moveit_config = (
        MoveItConfigsBuilder("abb_irb1600id", package_name="irb1600id_moveit_config")
        .planning_pipelines(pipelines=["ompl"], default_planning_pipeline="ompl")
        .moveit_cpp(file_path="config/moveit_py.yaml")
        .to_moveit_configs()
    )

    diag = Node(
        package="irb1600id_moveit_config",
        executable="diag_scene.py",
        name="scene_diag",
        output="screen",
        emulate_tty=True,
        parameters=[moveit_config.to_dict()],
    )

    return LaunchDescription([
        # Belt and braces: even with the logger, keep Python from buffering.
        SetEnvironmentVariable("PYTHONUNBUFFERED", "1"),
        diag,
    ])
