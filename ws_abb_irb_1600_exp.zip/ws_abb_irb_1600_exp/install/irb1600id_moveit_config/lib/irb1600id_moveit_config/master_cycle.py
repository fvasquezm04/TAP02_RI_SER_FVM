#!/usr/bin/env python3
"""
Part 4 - full pick-and-place cycle for the ABB IRB 1600ID.

    4A  HOME      -> pre-pick    free motion around the obstacle, OMPL
    4B  pre-pick  -> pick        straight descent, cubic vs quintic profile
        pick      -> pre-pick    retreat with the part attached (blue limits)
    4C  pre-pick  -> pre-place   free motion, chosen planner
    4D  pre-place -> place       straight descent, chosen profile
        place     -> pre-place   retreat, part released

Run it with:

    ros2 launch irb1600id_moveit_config demo.launch.py          # terminal 1
    ros2 run    irb1600id_moveit_config scene.py                # terminal 2
    ros2 launch irb1600id_moveit_config run_cycle.launch.py     # terminal 3

Everything printed with a [RESULT] prefix is a number that belongs in the
video or the report. Results are also written to part4_results.json.
"""

import json
import os
import sys
import time

import numpy as np
import rclpy
from geometry_msgs.msg import Pose, PoseStamped

from moveit.planning import MoveItPy, PlanRequestParameters
from moveit.core.robot_state import RobotState
from moveit.core.robot_trajectory import RobotTrajectory

import cartesian
import execution
import profiles
import scene as scene_mod

GROUP = "manipulator"
TIP = "tool0"
FRAME = "base_link"
JOINT_NAMES = [f"joint_{i}" for i in range(1, 7)]

# Forward kinematics of the SRDF states (verified against the URDF chain).
PICK_POS = (0.3677, -0.8509, 0.2155)
PICK_QUAT = (0.3977, 0.6050, -0.3789, 0.5764)
PLACE_POS = (0.8846, 1.0814, 0.0880)
PLACE_QUAT = (-0.3064, 0.6464, 0.2993, 0.6314)

APPROACH = 0.100          # vertical stand-off for pre-pick / pre-place, metres
CONTACT_GAP = 0.002       # stop 2 mm short of contact; the grasp is the attach,
                          # not a physical touch, and this keeps the final
                          # waypoint out of collision without touching the ACM
PLANNER_TRIALS = 10       # repeats per planner in 4A


def plan_with_fallback(arm, moveit, chosen, chosen_label, logger, stage):
    """
    Plan with the planner selected in 4A; if it fails, fall back to
    RRTConnect.

    RRT* is an optimizing planner on a fixed time budget: on a harder problem
    it can burn the whole budget and return TIMED_OUT without ever producing a
    first solution, where RRTConnect would have found one in milliseconds. The
    comparison in 4A stays honest either way - this fallback only affects which
    trajectory actually gets executed, and it is logged when it fires.
    """
    plan = arm.plan(single_plan_parameters=chosen)
    if plan:
        return plan

    logger.warn(f"{stage}: {chosen_label} failed, retrying with RRTConnect")
    fallback = PlanRequestParameters(moveit, "ompl_rrtconnect")
    arm.set_start_state_to_current_state()
    return arm.plan(single_plan_parameters=fallback)


def current_joints(moveit, group):
    """Live joint configuration, straight from the planning scene monitor."""
    with moveit.get_planning_scene_monitor().read_only() as scene:
        return list(scene.current_state.get_joint_group_positions(group))


def make_pose(position, quat):
    pose = Pose()
    pose.position.x, pose.position.y, pose.position.z = [float(v) for v in position]
    pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w = \
        [float(v) for v in quat]
    return pose


def stamped(pose):
    ps = PoseStamped()
    ps.header.frame_id = FRAME
    ps.pose = pose
    return ps


def raised(position, dz):
    return (position[0], position[1], position[2] + dz)


# --------------------------------------------------------------------------
# Trajectory metrics for the 4A planner comparison
# --------------------------------------------------------------------------

def trajectory_metrics(traj_msg, fk):
    """Joint path length, Cartesian path length and a smoothness figure."""
    q = np.array([p.positions for p in traj_msg.joint_trajectory.points], dtype=float)
    if len(q) < 3:
        return {"joint_path_len": 0.0, "cartesian_path_len": 0.0,
                "smoothness": 0.0, "n_points": len(q)}

    joint_len = float(np.sum(np.linalg.norm(np.diff(q, axis=0), axis=1)))

    xyz = np.array([fk(row) for row in q])
    cart_len = float(np.sum(np.linalg.norm(np.diff(xyz, axis=0), axis=1)))

    # Smoothness: RMS of the second difference of the joint path, normalised by
    # path length so a longer path is not penalised twice. Lower is smoother.
    second = np.diff(q, n=2, axis=0)
    smoothness = float(np.sqrt(np.mean(second ** 2)) / max(joint_len, 1e-9))

    return {"joint_path_len": joint_len, "cartesian_path_len": cart_len,
            "smoothness": smoothness, "n_points": int(len(q))}


def compare_planners(moveit, arm, goal_state, fk, logger, trials=PLANNER_TRIALS):
    """
    4A - plan the same HOME -> pre-pick motion with two OMPL planners and
    report timing, length and smoothness. Repeated because both planners are
    randomised; a single run tells you nothing.
    """
    candidates = {
        "RRTConnect": "ompl_rrtconnect",
        "RRTstar": "ompl_rrtstar",
    }
    summary = {}

    for label, param_set in candidates.items():
        params = PlanRequestParameters(moveit, param_set)
        runs = []
        for i in range(trials):
            arm.set_start_state(configuration_name="HOME")
            # Fixed joint-space goal, not a pose goal. With a pose goal each
            # trial draws a different IK solution, so the two planners end up
            # solving different problems and the path-length spread swamps the
            # difference between them.
            arm.set_goal_state(robot_state=goal_state)
            wall_start = time.perf_counter()
            result = arm.plan(single_plan_parameters=params)
            wall = time.perf_counter() - wall_start
            if not result:
                logger.warn(f"{label}: trial {i + 1} failed to find a plan")
                continue
            msg = result.trajectory.get_robot_trajectory_msg()
            metrics = trajectory_metrics(msg, fk)
            metrics["planning_time"] = float(getattr(result, "planning_time", wall))
            metrics["wall_time"] = wall
            runs.append(metrics)

        if not runs:
            logger.error(f"{label}: every trial failed")
            continue

        summary[label] = {
            "successes": len(runs),
            "trials": trials,
            "planning_time_mean": float(np.mean([r["planning_time"] for r in runs])),
            "planning_time_std": float(np.std([r["planning_time"] for r in runs])),
            "joint_path_len_mean": float(np.mean([r["joint_path_len"] for r in runs])),
            "joint_path_len_std": float(np.std([r["joint_path_len"] for r in runs])),
            "cartesian_path_len_mean": float(np.mean([r["cartesian_path_len"] for r in runs])),
            "smoothness_mean": float(np.mean([r["smoothness"] for r in runs])),
        }

    logger.info("[RESULT] 4A planner comparison over "
                f"{trials} trials, HOME -> pre-pick:")
    header = (f"  {'planner':<12}{'t_plan [s]':>14}{'joint len [rad]':>18}"
              f"{'cart len [m]':>14}{'smooth':>12}{'ok':>6}")
    logger.info(header)
    for label, s in summary.items():
        logger.info(
            f"  {label:<12}"
            f"{s['planning_time_mean']:>9.4f}±{s['planning_time_std']:<4.3f}"
            f"{s['joint_path_len_mean']:>12.4f}±{s['joint_path_len_std']:<4.3f}"
            f"{s['cartesian_path_len_mean']:>14.4f}"
            f"{s['smoothness_mean']:>12.6f}"
            f"{s['successes']:>4}/{s['trials']}"
        )

    # Selection rule, stated explicitly so it can be defended in the viva:
    # among planners that always succeed, take the shorter joint-space path;
    # break ties on planning time.
    def score(item):
        label, s = item
        # Round the path length before comparing. When both planners converge
        # on the same path - which happens on short, weakly constrained
        # motions - a difference in the fourth decimal is numerical noise, and
        # letting it decide the winner picked RRT* and its 5 s budget over a
        # RRTConnect solution that was, in every way that matters, identical.
        return (round(s["joint_path_len_mean"], 3), s["planning_time_mean"])

    best = min(summary.items(), key=score)[0] if summary else "RRTConnect"
    logger.info(f"[RESULT] 4A selected planner: {best}")
    return best, candidates[best], summary


# --------------------------------------------------------------------------
# Fine approach, 4B / 4D
# --------------------------------------------------------------------------

def fine_approach(planner, runner, moveit, robot_model, ref_state, fk, logger,
                  start_pos, quat, drop, limits, quintic, execute=True,
                  max_step=0.002, gap=0.0, current_q=None, log_path=None):
    """
    Plan a straight vertical segment and impose the chosen profile on it.
    Returns (info dict, executed bool).

    `gap` shortens the descent so the flange stops just above the part.
    `current_q` is only used for diagnostics when the service refuses.
    `log_path`, if given, is forwarded to cartesian.retime() so the per-
    waypoint (t, q, qdot, s, sdot_target) rows used by Part 5's Jacobian/
    velocity check get written to disk for the segment actually executed.
    """
    z_target = start_pos[2] - drop + (gap if drop > 0 else -gap)
    target = make_pose((start_pos[0], start_pos[1], z_target), quat)

    if current_q is not None:
        here = fk(current_q)
        logger.info(f"  fine approach: tool now at "
                    f"({here[0]:.4f}, {here[1]:.4f}, {here[2]:.4f}), "
                    f"target z {z_target:.4f}, "
                    f"start/target gap {abs(here[2] - start_pos[2]) * 1000:.1f} mm in z")

    start_state = None
    if current_q is not None:
        start_state = planner.start_state_from(JOINT_NAMES, current_q)

    traj_msg, fraction, _ = planner.compute_diagnosing(
        [target], logger, start_state=start_state, max_step=max_step
    )

    if fraction < 0.99:
        logger.error(
            f"Cartesian path only {fraction * 100:.1f}% complete. "
            "fraction 0.0 means the very first interpolation step was rejected: "
            "either the start state is already in collision, or IK failed at the "
            "first step. Check RViz for red links."
        )
        return None, False

    try:
        traj_msg, info = cartesian.retime(
            traj_msg, fk, v_max=limits["v_max"], a_max=limits["a_max"],
            quintic=quintic, csv_path=log_path,
        )
    except cartesian.ShortPathError as exc:
        logger.error(f"  {exc}")
        return None, False
    logger.info(f"[RESULT] fine approach, {info['profile']} profile:\n"
                + cartesian.format_info(info))

    if not execute:
        return info, False

    ok = runner.run(traj_msg.joint_trajectory)
    return info, ok


# --------------------------------------------------------------------------

def main():
    rclpy.init()

    moveit = MoveItPy(node_name="pick_and_place_cycle")
    arm = moveit.get_planning_component(GROUP)
    robot_model = moveit.get_robot_model()
    logger = moveit.get_logger() if hasattr(moveit, "get_logger") else None

    helper = rclpy.create_node("cycle_helper")
    if logger is None:
        logger = helper.get_logger()

    # Forward kinematics on a scratch state, used for arc length and metrics.
    fk_state = RobotState(robot_model)

    def fk(joint_positions):
        fk_state.set_joint_group_positions(GROUP, list(joint_positions))
        fk_state.update()
        return np.asarray(fk_state.get_global_link_transform(TIP))[:3, 3]

    results = {}

    # --- scene -----------------------------------------------------------
    objects = scene_mod.build_objects()

    # move_group's scene: drives RViz and /compute_cartesian_path
    scene_client = scene_mod.SceneClient(helper)
    scene_client.add_objects(objects)

    # MoveItPy's own scene: drives OMPL in 4A and 4C. Separate monitor, so it
    # has to be populated separately or the planner routes through the pole.
    psm = moveit.get_planning_scene_monitor()
    scene_mod.apply_to_local_scene(psm, objects)
    logger.info("Planning scene applied to move_group and to MoveItPy")

    if scene_mod.verify_obstacle_seen(psm, RobotState(robot_model), GROUP, logger):
        logger.info("[RESULT] obstacle self-test PASSED - the configuration "
                    "that intersects the pole is reported as colliding, so 4A "
                    "is planning against a real obstacle")
    else:
        logger.error("obstacle self-test FAILED. If no alpha collided, the "
                     "pole is not in MoveItPy's scene and 4A would plan "
                     "through it. If the endpoints collided, the ACM has lost "
                     "its SRDF entries. Stopping either way.")
        return

    pre_pick = raised(PICK_POS, APPROACH)
    pre_place = raised(PLACE_POS, APPROACH)
    pre_pick_pose = make_pose(pre_pick, PICK_QUAT)
    pre_place_pose = make_pose(pre_place, PLACE_QUAT)

    # --- go to HOME ------------------------------------------------------
    arm.set_start_state_to_current_state()
    arm.set_goal_state(configuration_name="HOME")
    plan = arm.plan()
    if plan:
        moveit.execute(plan.trajectory, controllers=[])
    else:
        logger.error("could not reach HOME")
        return

    # --- 4A --------------------------------------------------------------
    # Solve IK once so both planners aim at the identical configuration.
    goal_state = RobotState(robot_model)
    goal_state.set_joint_group_positions(GROUP, [0.0] * 6)
    goal_state.update()
    if not goal_state.set_from_ik(GROUP, pre_pick_pose, TIP, timeout=1.0):
        logger.error("IK failed for pre-pick - check reach and orientation")
        return
    goal_state.update()
    logger.info("[RESULT] 4A goal configuration (rad): "
                + ", ".join(f"{v:.4f}" for v in
                            goal_state.get_joint_group_positions(GROUP)))

    best_label, best_params, planner_summary = compare_planners(
        moveit, arm, goal_state, fk, logger
    )
    results["4A_planner_comparison"] = planner_summary
    results["4A_selected"] = best_label
    chosen = PlanRequestParameters(moveit, best_params)

    arm.set_start_state_to_current_state()
    arm.set_goal_state(robot_state=goal_state)
    plan = arm.plan(single_plan_parameters=chosen)
    if not plan:
        logger.error("4A execution plan failed")
        return
    moveit.execute(plan.trajectory, controllers=[])
    time.sleep(0.5)

    # --- 4B: compare both profiles, execute the better one ---------------
    ref_state = RobotState(robot_model)
    ref_state.set_joint_group_positions(GROUP, list(
        plan.trajectory.get_robot_trajectory_msg().joint_trajectory.points[-1].positions))
    ref_state.update()

    planner = cartesian.CartesianPlanner(helper, group=GROUP, link=TIP, frame=FRAME)
    runner = execution.TrajectoryRunner(helper)

    cubic_info, _ = fine_approach(
        planner, runner, moveit, robot_model, ref_state, fk, logger,
        pre_pick, PICK_QUAT, APPROACH, profiles.LIMITS["red"],
        quintic=False, execute=False, gap=CONTACT_GAP,
        current_q=ref_state.get_joint_group_positions(GROUP),
    )
    quintic_info, _ = fine_approach(
        planner, runner, moveit, robot_model, ref_state, fk, logger,
        pre_pick, PICK_QUAT, APPROACH, profiles.LIMITS["red"],
        quintic=True, execute=False, gap=CONTACT_GAP,
        current_q=current_joints(moveit, GROUP),
    )
    results["4B_cubic"] = cubic_info
    results["4B_quintic"] = quintic_info

    # Selection rule: both respect the caps by construction, so pick on
    # smoothness (RMS joint jerk), which is what the statement asks about.
    use_quintic = True
    if cubic_info and quintic_info:
        use_quintic = quintic_info["jerk_rms"] <= cubic_info["jerk_rms"]
    results["4B_selected"] = "quintic" if use_quintic else "cubic"
    logger.info(f"[RESULT] 4B selected profile: {results['4B_selected']}")

    fine_approach(
        planner, runner, moveit, robot_model, ref_state, fk, logger,
        pre_pick, PICK_QUAT, APPROACH, profiles.LIMITS["red"],
        quintic=use_quintic, execute=True, gap=CONTACT_GAP,
        current_q=current_joints(moveit, GROUP),
        log_path="part5_4B_waypoints.csv",
    )

    # --- grasp and retreat (blue limits) ---------------------------------
    scene_client.attach("piece")
    scene_mod.attach_local(psm, "piece")
    logger.info("piece attached to link_6 in both scenes")
    time.sleep(0.5)

    fine_approach(
        planner, runner, moveit, robot_model, ref_state, fk, logger,
        (PICK_POS[0], PICK_POS[1], PICK_POS[2] + CONTACT_GAP),
        PICK_QUAT, -APPROACH, profiles.LIMITS["blue"],
        quintic=use_quintic, execute=True,
        current_q=current_joints(moveit, GROUP),
    )

    # --- 4C --------------------------------------------------------------
    arm.set_start_state_to_current_state()
    arm.set_goal_state(pose_stamped_msg=stamped(pre_place_pose), pose_link=TIP)
    plan = plan_with_fallback(arm, moveit, chosen, best_label, logger, "4C")
    if not plan:
        logger.error("4C plan failed with both planners")
        return
    results["4C"] = trajectory_metrics(plan.trajectory.get_robot_trajectory_msg(), fk)
    moveit.execute(plan.trajectory, controllers=[])
    time.sleep(0.5)

    # --- 4D --------------------------------------------------------------
    info, _ = fine_approach(
        planner, runner, moveit, robot_model, ref_state, fk, logger,
        pre_place, PLACE_QUAT, APPROACH, profiles.LIMITS["red"],
        quintic=use_quintic, execute=True, gap=CONTACT_GAP,
        current_q=current_joints(moveit, GROUP),
        log_path="part5_4D_waypoints.csv",
    )
    results["4D"] = info

    scene_client.detach("piece")
    scene_mod.detach_local(psm, "piece")
    logger.info("piece released in both scenes")
    time.sleep(0.5)

    fine_approach(
        planner, runner, moveit, robot_model, ref_state, fk, logger,
        (PLACE_POS[0], PLACE_POS[1], PLACE_POS[2] + CONTACT_GAP),
        PLACE_QUAT, -APPROACH, profiles.LIMITS["blue"],
        quintic=use_quintic, execute=True,
        current_q=current_joints(moveit, GROUP),
    )

    # --- back to HOME ----------------------------------------------------
    arm.set_start_state_to_current_state()
    arm.set_goal_state(configuration_name="HOME")
    plan = plan_with_fallback(arm, moveit, chosen, best_label, logger, "return")
    if plan:
        moveit.execute(plan.trajectory, controllers=[])

    with open("part4_results.json", "w") as handle:
        json.dump(results, handle, indent=2)
    logger.info("[RESULT] cycle complete, numbers written to part4_results.json")

    helper.destroy_node()
    sys.stdout.flush()
    sys.stderr.flush()
    # Skip the MoveItCpp destructor, which segfaults on shutdown in moveit_py
    # and would otherwise end every run with a scary exit code -11.
    os._exit(0)


if __name__ == "__main__":
    main()
