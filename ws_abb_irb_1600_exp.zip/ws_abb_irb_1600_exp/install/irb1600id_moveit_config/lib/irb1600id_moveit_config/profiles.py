#!/usr/bin/env python3
"""
Part 4B / 4D - temporal profiles for the fine-approach segments.

Pure math, no ROS. Two jobs:

  1) Provide s(t), s_dot(t), s_ddot(t) for a rest-to-rest motion along a
     straight Cartesian segment of length L, under the consultancy limits.
  2) Provide the inverse t(s), which is what actually lets us impose the
     profile on the path returned by /compute_cartesian_path. That service
     gives us a *path* resampled uniformly in space with no timing; we
     measure the arc length of each returned waypoint and ask this module
     "at what time should the robot be at that arc length?".

Limits from the statement:
    red  (outbound, pre-pick -> pick, pre-place -> place): 0.200 m/s, 0.300 m/s^2
    blue (return,   pick -> pre-pick, place -> pre-place): 0.100 m/s, 0.020 m/s^2

Cubic,  s(tau) = L (3 tau^2 - 2 tau^3),  tau = t/tf
    s_dot_max  = 3L / (2 tf)        at tau = 1/2
    s_ddot_max = 6L / tf^2          at tau = 0 and tau = 1

Quintic, s(tau) = L (10 tau^3 - 15 tau^4 + 6 tau^5)
    s_dot_max  = 15L / (8 tf)       at tau = 1/2
    s_ddot_max = 10L / (sqrt(3) tf^2)
"""

import numpy as np

# Consultancy limits, metres and seconds.
LIMITS = {
    "red":  {"v_max": 0.200, "a_max": 0.300},
    "blue": {"v_max": 0.100, "a_max": 0.020},
}


def min_time(length, v_max, a_max, quintic=False):
    """Shortest tf that violates neither the velocity nor the acceleration cap."""
    length = abs(float(length))
    if quintic:
        tf_v = (15.0 * length) / (8.0 * v_max)
        tf_a = np.sqrt((10.0 * length) / (np.sqrt(3.0) * a_max))
    else:
        tf_v = (3.0 * length) / (2.0 * v_max)
        tf_a = np.sqrt((6.0 * length) / a_max)
    return max(tf_v, tf_a), tf_v, tf_a


def evaluate(length, tf, t, quintic=False):
    """Return (s, s_dot, s_ddot) at time(s) t. t may be a scalar or an array."""
    t = np.clip(np.asarray(t, dtype=float), 0.0, tf)
    tau = t / tf
    L = float(length)
    if quintic:
        s = L * (10 * tau**3 - 15 * tau**4 + 6 * tau**5)
        sd = L * (30 * tau**2 - 60 * tau**3 + 30 * tau**4) / tf
        sdd = L * (60 * tau - 180 * tau**2 + 120 * tau**3) / tf**2
    else:
        s = L * (3 * tau**2 - 2 * tau**3)
        sd = L * (6 * tau - 6 * tau**2) / tf
        sdd = L * (6 - 12 * tau) / tf**2
    return s, sd, sdd


def time_at_arclength(length, tf, s_query, quintic=False, samples=4001):
    """
    Inverse of s(t): given an arc length travelled, return the time at which
    the profile reaches it.

    s(t) is monotonically increasing for both polynomials, so a dense sample
    plus np.interp is exact enough (sub-millisecond) and has no convergence
    risk, unlike solving the quintic root-by-root.
    """
    t_grid = np.linspace(0.0, tf, samples)
    s_grid, _, _ = evaluate(length, tf, t_grid, quintic=quintic)
    s_grid[0] = 0.0
    s_grid[-1] = float(length)
    s_q = np.clip(np.asarray(s_query, dtype=float), 0.0, float(length))
    return np.interp(s_q, s_grid, t_grid)


def waypoints(length, v_max, a_max, n_intermediate=4, quintic=False):
    """
    The 3-4 intermediate points the statement asks for, as
    (t, s, s_dot, s_ddot) rows including the endpoints.
    """
    tf, _, _ = min_time(length, v_max, a_max, quintic=quintic)
    t = np.linspace(0.0, tf, n_intermediate + 2)
    s, sd, sdd = evaluate(length, tf, t, quintic=quintic)
    return tf, np.column_stack([t, s, sd, sdd])


def _report(name, length, v_max, a_max):
    print(f"\n{'=' * 62}\n{name}   L = {length * 1000:.0f} mm   "
          f"v_max = {v_max} m/s   a_max = {a_max} m/s^2\n{'=' * 62}")
    for quintic in (False, True):
        label = "QUINTIC" if quintic else "CUBIC  "
        tf, tf_v, tf_a = min_time(length, v_max, a_max, quintic=quintic)
        binding = "acceleration" if tf_a >= tf_v else "velocity"
        _, rows = waypoints(length, v_max, a_max, quintic=quintic)
        print(f"\n{label}  tf = {tf:.4f} s   "
              f"(tf_v = {tf_v:.4f}, tf_a = {tf_a:.4f} -> {binding} is binding)")
        print(f"  {'t [s]':>8} {'s [mm]':>10} {'v [m/s]':>10} {'a [m/s^2]':>11}")
        for t, s, sd, sdd in rows:
            print(f"  {t:8.4f} {s * 1000:10.3f} {sd:10.4f} {sdd:11.4f}")
        print(f"  peak |v| = {np.abs(rows[:, 2]).max():.4f} m/s   "
              f"peak |a| = {np.abs(rows[:, 3]).max():.4f} m/s^2")


def _plots(length):
    """Figures for the video. Skipped silently if matplotlib is unavailable."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n[profiles] matplotlib not installed, skipping plots.")
        return

    lim = LIMITS["red"]
    fig, axes = plt.subplots(3, 1, figsize=(8, 9), sharex=True)
    for quintic, colour in ((False, "tab:blue"), (True, "tab:red")):
        label = "quintic" if quintic else "cubic"
        tf, _, _ = min_time(length, lim["v_max"], lim["a_max"], quintic=quintic)
        t = np.linspace(0, tf, 500)
        s, sd, sdd = evaluate(length, tf, t, quintic=quintic)
        axes[0].plot(t, s * 1000, colour, label=f"{label} (tf={tf:.3f}s)")
        axes[1].plot(t, sd, colour, label=label)
        axes[2].plot(t, sdd, colour, label=label)

    axes[1].axhline(lim["v_max"], ls="--", c="k", lw=0.8, label="v limit")
    axes[2].axhline(lim["a_max"], ls="--", c="k", lw=0.8, label="a limit")
    axes[2].axhline(-lim["a_max"], ls="--", c="k", lw=0.8)
    axes[0].set_ylabel("arc length [mm]")
    axes[1].set_ylabel("speed [m/s]")
    axes[2].set_ylabel("acceleration [m/s²]")
    axes[2].set_xlabel("time [s]")
    for ax in axes:
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
    axes[0].set_title("Fine approach 4B — cubic vs quintic, red-segment limits")
    fig.tight_layout()
    fig.savefig("profiles_4b.png", dpi=150)
    print("\n[profiles] wrote profiles_4b.png")


if __name__ == "__main__":
    APPROACH = 0.100  # 100 mm vertical approach, pre-pick -> pick
    _report("4B  pre-pick -> pick  (red)", APPROACH, **LIMITS["red"])
    _report("4B' pick -> pre-pick  (blue retreat)", APPROACH, **LIMITS["blue"])
    _plots(APPROACH)
