#!/usr/bin/env python3
"""
Part 4B / 4D - straight-line approach with an imposed temporal profile.

Two problems this file solves.

1. moveit_py has no compute_cartesian_path.
   The Python bindings never wrapped it (moveit2 issue #2401), so
   `arm.compute_cartesian_path(...)` raises AttributeError. The underlying
   capability is still there - move_group advertises /compute_cartesian_path
   (moveit_msgs/srv/GetCartesianPath), which is the exact same server-side code
   that MoveGroupInterface::computeCartesianPath() calls. We call the service
   directly.

2. computeCartesianPath throws the timing away.
   Whatever times you attach to the waypoints you hand it, the service returns
   a path resampled uniformly in *space* at max_step, with time_from_start
   either zero or meaningless. Generating cubic/quintic waypoints and then
   passing them straight to the service accomplishes nothing measurable.

   So the profile is imposed afterwards: measure the Cartesian arc length of
   every returned joint waypoint by forward kinematics, then ask the profile at
   what time it reaches that arc length, and write that into time_from_start.
   Joint velocities and accelerations follow by finite differences.

   This is also what makes Part 5 checkable: after retiming, the tool speed
   |dp/dt| along the segment should reproduce the profile's s_dot(t) to within
   the discretisation error, and that is the quantity the Jacobian predicts.
"""

import numpy as np
import rclpy
from rclpy.node import Node

from moveit_msgs.msg import Constraints, RobotState
from moveit_msgs.srv import GetCartesianPath
from sensor_msgs.msg import JointState

import profiles


class ShortPathError(ValueError):
    """Raised when a returned path is too short to carry a time profile."""


class CartesianPlanner:
    """Synchronous client for /compute_cartesian_path."""

    def __init__(self, node: Node, group="manipulator", link="tool0",
                 frame="base_link", timeout=10.0):
        self._node = node
        self.group = group
        self.link = link
        self.frame = frame
        self._client = node.create_client(GetCartesianPath, "/compute_cartesian_path")
        if not self._client.wait_for_service(timeout_sec=timeout):
            raise RuntimeError(
                "/compute_cartesian_path not available - move_group is not running."
            )

    @staticmethod
    def start_state_from(joint_names, positions):
        """
        Build an explicit start state.

        Leaving request.start_state empty is not safe: robotStateMsgToRobotState
        rejects a non-diff RobotState whose joint_state carries no names, logging
        "Found empty JointState message". Whether the service then falls back to
        the current state is an implementation detail we should not rely on, so
        we state the start configuration outright.
        """
        state = RobotState()
        state.joint_state = JointState()
        state.joint_state.name = list(joint_names)
        state.joint_state.position = [float(v) for v in positions]
        state.is_diff = False
        return state

    def compute(self, waypoints, start_state: RobotState = None,
                max_step=0.002, avoid_collisions=True):
        """
        waypoints: list of geometry_msgs/Pose in self.frame, NOT including the
        current pose. Returns (moveit_msgs/RobotTrajectory, fraction).

        max_step is deliberately small (2 mm). The retiming samples the profile
        at these points, so a coarse step gives a coarse velocity profile.
        """
        request = GetCartesianPath.Request()
        request.header.frame_id = self.frame
        request.header.stamp = self._node.get_clock().now().to_msg()
        request.group_name = self.group
        request.link_name = self.link
        request.waypoints = list(waypoints)
        request.max_step = float(max_step)
        request.jump_threshold = 0.0
        request.avoid_collisions = bool(avoid_collisions)
        request.path_constraints = Constraints()
        # Jazzy's GetCartesianPath carries these; leaving them at 0.0 makes the
        # post-hoc time parameterization complain. We overwrite the timing in
        # retime() anyway, but keep them sane.
        for field, value in (("max_velocity_scaling_factor", 1.0),
                             ("max_acceleration_scaling_factor", 1.0)):
            if hasattr(request, field):
                setattr(request, field, value)
        if start_state is not None:
            request.start_state = start_state

        future = self._client.call_async(request)
        rclpy.spin_until_future_complete(self._node, future, timeout_sec=30.0)
        response = future.result()
        if response is None:
            raise RuntimeError("/compute_cartesian_path call timed out")
        return response.solution, float(response.fraction)

    def compute_diagnosing(self, waypoints, logger, start_state=None,
                           max_step=0.002):
        """
        Compute with collision avoidance on. If that returns nothing at all,
        immediately retry with avoidance off - purely to find out WHICH of the
        two possible causes we are looking at, because the symptom is identical:

          succeeds without avoidance -> something in the scene is blocking the
              descent, and we need to know what
          fails either way           -> IK cannot solve the straight line, so
              it is a kinematics/orientation problem, not a scene problem

        Returns (trajectory, fraction, used_collision_avoidance).
        """
        traj, fraction = self.compute(
            waypoints, start_state=start_state, max_step=max_step,
            avoid_collisions=True,
        )
        if fraction >= 0.99:
            return traj, fraction, True

        logger.warn(f"  with avoid_collisions=True  -> fraction {fraction:.3f}")
        traj_nc, fraction_nc = self.compute(
            waypoints, start_state=start_state, max_step=max_step,
            avoid_collisions=False,
        )
        logger.warn(f"  with avoid_collisions=False -> fraction {fraction_nc:.3f}")

        if fraction_nc >= 0.99:
            logger.error(
                "  DIAGNOSIS: the straight line is kinematically fine; "
                "something in the planning scene is in the way. Most likely the "
                "part or the pick table sits higher than the tool expects."
            )
        else:
            logger.error(
                "  DIAGNOSIS: IK cannot follow the straight line even with "
                "collisions ignored. This is a kinematics problem - check the "
                "target orientation and whether the descent crosses a "
                "singularity or a joint limit."
            )
        return traj_nc, fraction_nc, False


def retime(traj_msg, fk, v_max, a_max, quintic=False, csv_path=None):
    """
    Impose a cubic or quintic profile on an untimed Cartesian path.

    traj_msg : moveit_msgs/RobotTrajectory returned by the service. Modified
               in place and also returned.
    fk       : callable, joint position list -> (3,) Cartesian position of the
               tool, in the same frame the path was planned in.
    csv_path : optional. If given, write one row per waypoint with columns
               t, q1..q6, qd1..qd6, s_target, sdot_target - everything Part 5
               needs to compute J(q)@qdot and compare it against the profile's
               own s_dot(t), independently of the finite-difference tool_speed
               already reported in `info`.

    Returns (traj_msg, info) where info holds the numbers the report needs.
    """
    points = traj_msg.joint_trajectory.points
    if len(points) < 3:
        # Not an error worth crashing on: it means the requested segment was
        # essentially zero length, which in practice means an earlier segment
        # did not execute and the robot never got where we thought it was.
        raise ShortPathError(
            f"path has only {len(points)} points - the segment is near zero "
            "length, so a previous motion probably did not execute"
        )

    q = np.array([p.positions for p in points], dtype=float)

    # Cartesian arc length at every waypoint.
    xyz = np.array([fk(row) for row in q], dtype=float)
    seg = np.linalg.norm(np.diff(xyz, axis=0), axis=1)
    s = np.concatenate([[0.0], np.cumsum(seg)])
    length = float(s[-1])
    if length < 1e-6:
        raise ValueError("path has zero Cartesian length")

    tf, tf_v, tf_a = profiles.min_time(length, v_max, a_max, quintic=quintic)
    t = profiles.time_at_arclength(length, tf, s, quintic=quintic)

    # The profile is flat at both ends, so several spatially distinct waypoints
    # can map to nearly the same instant. Nudge them apart or the controller
    # rejects the trajectory for non-monotonic time.
    for i in range(1, len(t)):
        if t[i] <= t[i - 1] + 1e-6:
            t[i] = t[i - 1] + 1e-6

    # Finite-difference derivatives in joint space.
    vel = np.zeros_like(q)
    vel[1:-1] = (q[2:] - q[:-2]) / (t[2:] - t[:-2])[:, None]
    acc = np.zeros_like(q)
    acc[1:-1] = (vel[2:] - vel[:-2]) / (t[2:] - t[:-2])[:, None]

    for i, point in enumerate(points):
        point.positions = [float(v) for v in q[i]]
        point.velocities = [float(v) for v in vel[i]]
        point.accelerations = [float(v) for v in acc[i]]
        sec = int(t[i])
        point.time_from_start.sec = sec
        point.time_from_start.nanosec = int(round((t[i] - sec) * 1e9))

    # Tool speed actually realised, for the 4B/4D and Part 5 verification.
    dt = np.diff(t)
    tool_speed = seg / dt
    tool_accel = np.diff(tool_speed) / dt[:-1] if len(dt) > 1 else np.array([0.0])

    # Jerk as the smoothness figure of merit: RMS of the third difference of
    # joint position, normalised by time, summed over joints.
    jerk = np.diff(acc, axis=0) / dt[:, None]
    jerk_rms = float(np.sqrt(np.mean(jerk ** 2)))

    info = {
        "profile": "quintic" if quintic else "cubic",
        "n_points": len(points),
        "length_m": length,
        "tf_s": tf,
        "tf_velocity_bound_s": tf_v,
        "tf_accel_bound_s": tf_a,
        "binding_constraint": "acceleration" if tf_a >= tf_v else "velocity",
        "peak_tool_speed": float(np.max(tool_speed)),
        "peak_tool_accel": float(np.max(np.abs(tool_accel))),
        "limit_tool_speed": v_max,
        "limit_tool_accel": a_max,
        "peak_joint_speed": float(np.max(np.abs(vel))),
        "peak_joint_accel": float(np.max(np.abs(acc))),
        "jerk_rms": jerk_rms,
    }

    if csv_path is not None:
        _, sdot_target, _ = profiles.evaluate(length, tf, t, quintic=quintic)
        import csv
        with open(csv_path, "w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                ["t"] + [f"q{i+1}" for i in range(q.shape[1])]
                + [f"qd{i+1}" for i in range(q.shape[1])]
                + ["s", "sdot_target"]
            )
            for i in range(len(points)):
                writer.writerow(
                    [t[i]] + list(q[i]) + list(vel[i]) + [s[i], sdot_target[i]]
                )

    return traj_msg, info


def format_info(info):
    return (
        f"  profile            : {info['profile']}\n"
        f"  waypoints          : {info['n_points']}\n"
        f"  segment length     : {info['length_m'] * 1000:.2f} mm\n"
        f"  duration tf        : {info['tf_s']:.4f} s "
        f"({info['binding_constraint']} bound)\n"
        f"  peak tool speed    : {info['peak_tool_speed']:.4f} m/s "
        f"(limit {info['limit_tool_speed']:.3f})\n"
        f"  peak tool accel    : {info['peak_tool_accel']:.4f} m/s^2 "
        f"(limit {info['limit_tool_accel']:.3f})\n"
        f"  peak joint speed   : {info['peak_joint_speed']:.4f} rad/s\n"
        f"  peak joint accel   : {info['peak_joint_accel']:.4f} rad/s^2\n"
        f"  RMS joint jerk     : {info['jerk_rms']:.4f} rad/s^3\n"
    )
