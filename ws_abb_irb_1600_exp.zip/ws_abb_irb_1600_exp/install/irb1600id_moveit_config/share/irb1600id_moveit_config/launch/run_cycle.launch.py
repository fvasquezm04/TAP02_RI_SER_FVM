from launch import LaunchDescription
from launch_ros.actions import Node
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    # The first argument must match the SRDF file name in config/, which is
    # abb_irb1600id.srdf. The previous version passed "irb1600id", so the
    # builder looked for config/irb1600id.srdf, failed to load the semantic
    # description, and MoveItPy came up with no planning group.
    moveit_config = (
        MoveItConfigsBuilder("abb_irb1600id", package_name="irb1600id_moveit_config")
        .planning_pipelines(pipelines=["ompl"], default_planning_pipeline="ompl")
        .moveit_cpp(file_path="config/moveit_py.yaml")
        .to_moveit_configs()
    )

    cycle = Node(
        package="irb1600id_moveit_config",
        executable="master_cycle.py",
        name="pick_and_place_cycle",
        output="screen",
        parameters=[moveit_config.to_dict()],
    )

    return LaunchDescription([cycle])
