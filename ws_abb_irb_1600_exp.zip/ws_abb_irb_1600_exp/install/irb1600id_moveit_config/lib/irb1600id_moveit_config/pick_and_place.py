#!/usr/bin/env python3
import rclpy
from moveit_msgs.msg import CollisionObject
from shape_msgs.msg import SolidPrimitive
from geometry_msgs.msg import Pose
import time

def create_collision_object(id, frame_id, shape_type, dimensions, position):
    """Helper function to build a collision object."""
    obj = CollisionObject()
    obj.header.frame_id = frame_id
    obj.id = id
    
    shape = SolidPrimitive()
    shape.type = shape_type
    shape.dimensions = dimensions
    
    pose = Pose()
    pose.position.x = position[0]
    pose.position.y = position[1]
    pose.position.z = position[2]
    # Quaternions default to 0,0,0,1 (no rotation) in geometry_msgs
    pose.orientation.w = 1.0 
    
    obj.primitives.append(shape)
    obj.primitive_poses.append(pose)
    obj.operation = CollisionObject.ADD
    return obj

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node('planning_scene_spawner')
    publisher = node.create_publisher(CollisionObject, '/collision_object', 10)
    
    node.get_logger().info("Waiting 2 seconds for MoveIt to connect...")
    time.sleep(2.0)
    
    # 1. The Deposit Table (Centered right under your PLACE coordinates)
    table = create_collision_object(
        id="table", frame_id="base_link", shape_type=SolidPrimitive.BOX,
        dimensions=[0.4, 0.4, 0.05], position=[0.885, 1.081, 0.025]
    )
    
    # 2. The Fixed Obstacle (Placed exactly between HOME Y=0 and PICK Y=-0.851)
    obstacle = create_collision_object(
        id="obstacle", frame_id="base_link", shape_type=SolidPrimitive.CYLINDER,
        dimensions=[0.6, 0.05], position=[0.500, -0.400, 0.3] 
    )
    
    # 3. The Piece (Centered right under your PICK coordinates)
    piece = create_collision_object(
        id="piece", frame_id="base_link", shape_type=SolidPrimitive.BOX,
        dimensions=[0.05, 0.05, 0.05], position=[0.368, -0.851, 0.19]
    )
    # Publish the objects to RViz
    publisher.publish(table)
    publisher.publish(obstacle)
    publisher.publish(piece)
    
    node.get_logger().info("Collision objects spawned! Check RViz.")
    
    # Clean up
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
