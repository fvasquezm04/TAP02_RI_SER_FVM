import numpy as np

def generate_trajectory(q0, qf, v_max, a_max, num_waypoints=4, is_quintic=False):
    """Generates waypoints obeying kinematic constraints."""
    distance = abs(qf - q0)
    
    # Calculate minimum time tf required to not exceed max velocity or acceleration
    if not is_quintic:
        # Cubic limits
        tf_v = (3 * distance) / (2 * v_max)
        tf_a = np.sqrt((6 * distance) / a_max)
    else:
        # Quintic limits
        tf_v = (15 * distance) / (8 * v_max)
        tf_a = np.sqrt((10 * distance) / (np.sqrt(3) * a_max))
        
    tf = max(tf_v, tf_a) 
    times = np.linspace(0, tf, num_waypoints)
    waypoints = []

    for t in times:
        if not is_quintic:
            # Cubic Polynomial: q(t) = a0 + a2*t^2 + a3*t^3
            a0 = q0
            a2 = 3 * (qf - q0) / (tf**2)
            a3 = -2 * (qf - q0) / (tf**3)
            pos = a0 + a2*(t**2) + a3*(t**3)
        else:
            # Quintic Polynomial: q(t) = a0 + a3*t^3 + a4*t^4 + a5*t^5
            a0 = q0
            a3 = 10 * (qf - q0) / (tf**3)
            a4 = -15 * (qf - q0) / (tf**4)
            a5 = 6 * (qf - q0) / (tf**5)
            pos = a0 + a3*(t**3) + a4*(t**4) + a5*(t**5)
        
        waypoints.append((t, pos))
        
    return tf, waypoints

# --- Test with the Red Path Constraints (Pre-Pick to Pick) ---
# Your PICK Z-coordinate is 0.216. We will start 10cm above it at 0.316.
q_start = 0.316
q_end = 0.216
v_limit = 0.200 # m/s
a_limit = 0.300 # m/s^2

print("--- CUBIC PROFILE ---")
tf_cubic, cubic_wpts = generate_trajectory(q_start, q_end, v_limit, a_limit, is_quintic=False)
print(f"Total Time: {tf_cubic:.3f} seconds")
for w in cubic_wpts:
    print(f"Time: {w[0]:.3f}s -> Z-Pos: {w[1]:.4f}m")

print("\n--- QUINTIC PROFILE ---")
tf_quintic, quintic_wpts = generate_trajectory(q_start, q_end, v_limit, a_limit, is_quintic=True)
print(f"Total Time: {tf_quintic:.3f} seconds")
for w in quintic_wpts:
    print(f"Time: {w[0]:.3f}s -> Z-Pos: {w[1]:.4f}m")